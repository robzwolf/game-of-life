# Other Meetings
In addition to the recorded meeting notes, Robbie and Steven also met on the
following dates and times:

- 16th January 2020, 11:15
- 27th January 2020, 11:00
- 28th January 2020, 14:30
- 4th February 2020, 14:00
- 13th February 2020, 11:15
- 21st February 2020, 12:00
- 27th February 2020, 14:00
- 10th March 2020, 14:30
- 27th March 2020, 14:00
- 30th March 2020, 13:30
- 3rd April 2020, 14:00
- 16th April 2020, 14:00
- 20th April 2020, 14:00
- 23rd April 2020, 14:30
- 28th April 2020, 14:00
- 1st May 2020, 15:30
- 11th May 2020, 13:00
- 19th May 2020, 16:00
- 28th May 2020, 14:00
- 5th June 2020, 14:00
- 6th July 2020, 14:30
- 13th July 2020, 14:30
- 21st July 2020, 13:00
- 3rd August 2020, 13:00
- 11th August 2020, 16:30
- 13th August 2020, 16:00


The topics discussed include the L3 project, Computer Science into Schools,
amongst other academic and personal matters.
